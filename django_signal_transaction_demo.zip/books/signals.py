from django.db.models.signals import post_save
from django.dispatch import receiver
from .models import Book, BookLog

@receiver(post_save, sender=Book)
def log_book_creation(sender, instance, created, **kwargs):
    if created:
        BookLog.objects.create(book=instance, message="Book created")
