from django.db import transaction
from books.models import Book, BookLog

def run():
    try:
        with transaction.atomic():
            Book.objects.create(title="Signal Transaction Test")
            raise Exception("Trigger rollback after signal")
    except:
        print("Transaction rolled back.")

    print("Book count:", Book.objects.count())
    print("BookLog count:", BookLog.objects.count())
